Lab assignment #2
Neural Machine Translation on EN-RU dataset
  [![Open In Colab](https://colab.research.google.com/assets/colab-badge.svg)](https://colab.research.google.com/github/girafe-ai/natural-language-processing/22s_made/homeworks/lab02_neural_machine_translation/lab02_Neural_Machine_Translation.ipynb)